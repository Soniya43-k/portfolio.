
import { motion } from "framer-motion";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white px-6 md:px-20">
      <section className="py-24 flex flex-col gap-4">
        <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-4xl md:text-6xl font-bold">
          Patta Soniya
        </motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="text-lg text-gray-300">
          Data Science | Machine Learning | Software Development
        </motion.p>
        <div className="flex gap-4 mt-4">
          <a href="https://github.com/Soniya43-k" target="_blank" className="px-4 py-2 bg-blue-600 rounded-xl">GitHub</a>
          <a href="mailto:soniyalingamurthy@gmail.com" className="px-4 py-2 bg-gray-700 rounded-xl">Contact</a>
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-semibold mb-4">About Me</h2>
        <p className="text-gray-300 leading-relaxed">
          Driven and detail-oriented professional passionate about building intelligent systems, designing data-driven
          solutions, and developing efficient software applications.
        </p>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-semibold mb-4">Skills</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-gray-300">
          <p>Python</p><p>Java</p><p>C</p><p>Node.js</p>
          <p>HTML/CSS/JS</p><p>Flask</p><p>MySQL</p>
          <p>MongoDB</p><p>ServiceNow (CSA,CAD)</p><p>Git & GitHub</p>
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-semibold mb-8">Projects</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-700">
            <h3 className="text-xl font-semibold mb-2">Garbage Classification</h3>
            <p className="text-gray-300 text-sm">MobileNetV2 model, 94% accuracy, Azure Flask deployment.</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-700">
            <h3 className="text-xl font-semibold mb-2">Leaf Disease Detection</h3>
            <p className="text-gray-300 text-sm">CNN model, 40% faster inference, explainability added.</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-700">
            <h3 className="text-xl font-semibold mb-2">Network Request Automation</h3>
            <p className="text-gray-300 text-sm">ServiceNow workflows, SLA tracking, reduced manual work by 70%.</p>
          </div>
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-semibold mb-4">Experience</h2>
        <div className="mb-6">
          <h3 className="text-xl font-semibold">AI Intern — Microsoft Azure</h3>
          <p className="text-gray-400 text-sm">Jun 2025 - Jul 2025</p>
          <p className="text-gray-300 mt-1">Built and deployed ML model on Azure via REST APIs.</p>
        </div>
        <div className="mb-6">
          <h3 className="text-xl font-semibold">Data Analytics Intern — SmartBridge</h3>
          <p className="text-gray-400 text-sm">May 2025 - Jul 2025</p>
          <p className="text-gray-300 mt-1">ETL pipelines, dashboards, visualization.</p>
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-semibold mb-4">Certifications</h2>
        <ul className="list-disc ml-6 text-gray-300">
          <li>ServiceNow CAD (2025)</li>
          <li>ServiceNow CSA (2025)</li>
          <li>Power BI — Infosys</li>
          <li>Network Automation — SmartBridge</li>
        </ul>
      </section>

      <section className="py-20 text-center">
        <h2 className="text-3xl font-semibold mb-4">Let's Connect</h2>
        <p className="text-gray-300">soniyalingamurthy@gmail.com • 6304685305</p>
      </section>
    </div>
  );
}
